import React from "react";
import '../styles/Navbar.css'
function Navbar(){
    return(
        <div className="navBar">
            <ul>
                <li>logo</li>
                <li>home</li>
                <li>home</li>
                <li>home</li>
            </ul>
        </div>
    );
}
export default Navbar;